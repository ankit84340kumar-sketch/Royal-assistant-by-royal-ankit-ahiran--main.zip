
# Zoya AI Assistant - Python Backend

Yeh Zoya AI Assistant ka Python (FastAPI) version hai. Ismein wahi same logic aur personality use ki gayi hai jo original Node.js/TypeScript version mein thi.

## Features
- **Zoya Personality**: Same witty, sassy, aur funny personality (Hinglish mix).
- **Gemini Integration**: Chat aur TTS (Text-to-Speech) ke liye Google Gemini API ka use.
- **Database**: Chat history ko save karne ke liye SQLite ka use kiya gaya hai.
- **Command Processing**: Browser commands (Open website, YouTube, Spotify, WhatsApp) handle karne ke liye logic.
- **Middleware**: Error handling aur logging ke liye proper middleware setup.

## Project Structure
- `app/main.py`: Main FastAPI application aur routes.
- `app/services/`: Core logic (Gemini, Database, Commands).
- `app/middleware/`: Error handling logic.
- `requirements.txt`: Python dependencies.
- `zoya_chat.db`: SQLite database file (startup pe auto-create hogi).

## Kaise Run Karein?

1. **Python Install Karein**:
   Make sure aapke system mein Python 3.9+ installed hai.

2. **Dependencies Install Karein**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Environment Variables Setup Karein**:
   `.env.example` file ko copy karke `.env` banayein aur apni `GEMINI_API_KEY` daalein.
   ```bash
   cp .env.example .env
   ```

4. **Server Start Karein**:
   ```bash
   uvicorn app.main:app --reload
   ```

5. **API Documentation Check Karein**:
   Server start hone ke baad aap `http://127.0.0.1:8000/docs` par jaakar saare API endpoints test kar sakte hain.

## API Endpoints
- `POST /chat`: Zoya se baat karne ke liye.
- `POST /audio`: Text ko Zoya ki voice (audio) mein convert karne ke liye.
- `POST /command`: User commands process karne ke liye.
- `GET /history`: Purani chat history dekhne ke liye.
- `POST /clear_history`: History clear karne ke liye.

---
**Note**: Original `liveService.ts` browser-side audio processing pe dependent tha, isliye Python backend mein uska placeholder diya gaya hai. Core chat aur command logic fully functional hai.
