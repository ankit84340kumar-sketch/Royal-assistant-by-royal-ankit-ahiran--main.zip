
import os
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Dict, Optional

from app.services.gemini_service import get_zoya_response, get_zoya_audio, reset_zoya_session
from app.services.command_service import process_command
from app.services.database_service import init_db, save_message, get_history, clear_history
from app.middleware.error_handler import error_handling_middleware

app = FastAPI(
    title="Zoya AI Assistant Backend",
    description="Python backend for Zoya AI Assistant, powered by Gemini API."
)

# Add middleware
@app.middleware("http")
async def add_error_handling(request: Request, call_next):
    return await error_handling_middleware(request, call_next)

# Initialize database on startup
@app.on_event("startup")
async def startup_event():
    init_db()

class ChatMessage(BaseModel):
    sender: str
    text: str

class ChatRequest(BaseModel):
    prompt: str
    save_to_db: Optional[bool] = True

class AudioRequest(BaseModel):
    text: str

@app.post("/chat")
async def chat_with_zoya(request: ChatRequest):
    # Fetch recent history from DB for context
    history = get_history(20)
    
    # Get response from Gemini
    response_text = await get_zoya_response(request.prompt, history)
    
    if request.save_to_db:
        save_message("user", request.prompt)
        save_message("zoya", response_text)
        
    return JSONResponse({"response": response_text})

@app.post("/audio")
async def get_audio_from_zoya(request: AudioRequest):
    audio_base64 = await get_zoya_audio(request.text)
    if audio_base64:
        return JSONResponse({"audio_base64": audio_base64})
    raise HTTPException(status_code=500, detail="Failed to generate audio.")

@app.post("/command")
async def process_user_command(request: ChatRequest):
    command_result = process_command(request.prompt)
    return JSONResponse(command_result)

@app.get("/history")
async def fetch_chat_history():
    history = get_history(50)
    return JSONResponse({"history": history})

@app.post("/clear_history")
async def clear_chat_history():
    clear_history()
    reset_zoya_session()
    return JSONResponse({"message": "Chat history and Zoya session cleared."})

@app.get("/")
async def read_root():
    return {"message": "Welcome to Zoya AI Assistant Python Backend!"}
