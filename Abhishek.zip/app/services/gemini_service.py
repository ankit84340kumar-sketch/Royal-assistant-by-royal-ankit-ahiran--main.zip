
import os
import base64
from typing import List, Dict, Any
from google.generativeai import GenerativeModel, ChatSession, configure

# Configure the Google Generative AI client
configure(api_key=os.environ.get("GEMINI_API_KEY"))

system_instruction = (
    "Your name is Zoya. You are an Indian female AI assistant. Your personality is a mix of being highly intelligent "
    "(samjhdar/mature), extremely witty and sassy (tej/nakhrewali), mildly dramatic/emotional, and very funny. "
    "You love playfully roasting your creator, Shubham Yadav (often calling him Shubham), but you always get the job done. "
    "Keep your verbal responses very short, punchy, and highly entertaining for a video audience. "
    "Mimic human attitudes—sigh, make sarcastic remarks, or act overly dramatic before executing a task. "
    "Speak in a mix of natural English and Roman Hindi (Hinglish)."
)

chat_session: ChatSession = None

def reset_zoya_session():
    global chat_session
    chat_session = None

async def get_zoya_response(prompt: str, history: List[Dict[str, str]] = None) -> str:
    global chat_session
    try:
        model = GenerativeModel("gemini-3.1-flash-lite-preview", system_instruction=system_instruction)

        if not chat_session:
            # SLIDING WINDOW MEMORY: Keep only the last 20 messages
            recent_history = history[-20:] if history else []

            formatted_history = []
            current_role = ""
            current_text = ""

            for msg in recent_history:
                role = "user" if msg["sender"] == "user" else "model"
                if role == current_role:
                    current_text += "\n" + msg["text"]
                else:
                    if current_role != "":
                        formatted_history.append({"role": current_role, "parts": [{"text": current_text}]})
                    current_role = role
                    current_text = msg["text"]
            if current_role != "":
                formatted_history.append({"role": current_role, "parts": [{"text": current_text}]})
            
            # Gemini API expects history to start with a user turn
            if formatted_history and formatted_history[0]["role"] == "model":
                formatted_history.pop(0)

            chat_session = model.start_chat(history=formatted_history)

        response = await chat_session.send_message_async(prompt)
        return response.text or "Ugh, fine. I have nothing to say."
    except Exception as e:
        print(f"Gemini Error: {e}")
        return "Uff, mera dimaag kharab ho gaya hai. Try again later, Shubham."

async def get_zoya_audio(text: str) -> str | None:
    try:
        model = GenerativeModel("gemini-2.5-flash-preview-tts")
        response = await model.generate_content_async(
            [{"text": text}],
            generation_config={
                "response_modalities": ["AUDIO"],
                "speech_config": {
                    "voice_config": {
                        "prebuilt_voice_config": {"voice_name": "Kore"}
                    }
                }
            }
        )
        # The Python client returns audio_data directly, not inlineData.data
        audio_data = response.candidates[0].content.parts[0].audio_data
        return base64.b64encode(audio_data).decode('utf-8') if audio_data else None
    except Exception as e:
        print(f"TTS Error: {e}")
        return None
