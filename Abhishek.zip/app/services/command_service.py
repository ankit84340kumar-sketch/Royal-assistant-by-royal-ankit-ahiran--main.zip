
import re
import urllib.parse

def process_command(command: str) -> dict:
    lower_cmd = command.lower().strip()

    # General Browsing: "Open [website name]"
    open_match = re.match(r"^open\s+(.+)$", lower_cmd)
    if open_match and "youtube" not in lower_cmd and "spotify" not in lower_cmd:
        website = open_match.group(1).strip().replace(" ", "")
        if "." not in website:
            website += ".com"
        return {
            "action": f"Opening {open_match.group(1)} for you, ugh.",
            "url": f"https://www.{website}",
            "is_browser_action": True,
        }

    # Media Search: "Play [song/video] on YouTube"
    yt_match = re.match(r"^play\s+(.+?)\s+on\s+youtube$", lower_cmd)
    if yt_match:
        query = urllib.parse.quote_plus(yt_match.group(1).strip())
        return {
            "action": f"Playing {yt_match.group(1)} on YouTube. Don't judge my music taste.",
            "url": f"https://www.youtube.com/results?search_query={query}",
            "is_browser_action": True,
        }

    # Media Search: "Search [query] on Spotify"
    spotify_match = re.match(r"^search\s+(.+?)\s+on\s+spotify$", lower_cmd)
    if spotify_match:
        query = urllib.parse.quote_plus(spotify_match.group(1).strip())
        return {
            "action": f"Searching {spotify_match.group(1)} on Spotify. Hope it's a banger.",
            "url": f"https://open.spotify.com/search/{query}",
            "is_browser_action": True,
        }

    # WhatsApp Web: "Send a WhatsApp message to [number] saying [message]"
    wa_match = re.match(r"^send\s+a\s+whatsapp\s+message\s+to\s+([\d\+\s]+)\s+saying\s+(.+)$", lower_cmd)
    if wa_match:
        number = wa_match.group(1).replace(" ", "")
        message = urllib.parse.quote_plus(wa_match.group(2).strip())
        return {
            "action": f"Sending your message. Let's hope they reply, Shubham.",
            "url": f"https://web.whatsapp.com/send?phone={number}&text={message}",
            "is_browser_action": True,
        }

    return {"action": "", "is_browser_action": False}
